var rules_8c =
[
    [ "addFrame", "rules_8c.html#ab6ca730042cb162571cb403dfaa5a4e8", null ],
    [ "showRules", "rules_8c.html#a3fc16568c796078d9294f977d0d33a83", null ]
];