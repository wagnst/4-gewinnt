var board_8c =
[
    [ "calcFieldAddress", "board_8c.html#a46db977f6db0fd0825f5ef5108c30e9e", null ],
    [ "clearBoard", "board_8c.html#aaf722a3aee3bf1d85e57eef1a4c4f02a", null ],
    [ "drawBoard", "board_8c.html#a8ba56fbeff5fd3e187fdfeb8af94f517", null ],
    [ "freeBoard", "board_8c.html#af594e2b93fd0ac869b722812724a58ba", null ],
    [ "getField", "board_8c.html#a6cf24a8fbcadd26575f5d4ef0066e3f3", null ],
    [ "newBoard", "board_8c.html#aa832cfb270f47cdcb3afca65656dd964", null ],
    [ "setField", "board_8c.html#ab0314fc030a3d0d9a0e2a5d4fad73bd0", null ],
    [ "myBoard", "board_8c.html#a3369d7d3ba0c47ba3025860fa01a4d9f", null ]
];