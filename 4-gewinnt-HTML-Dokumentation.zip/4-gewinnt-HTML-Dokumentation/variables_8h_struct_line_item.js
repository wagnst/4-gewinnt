var variables_8h_struct_line_item =
[
    [ "align", "variables_8h.html#a1a9adf6b9d56e489b08ae59280037ecf", null ],
    [ "byteSize", "variables_8h.html#a8b14489b895b643b5c7e278823cc5910", null ],
    [ "length", "variables_8h.html#a5969bbd296f3dffab898cbe19f06ea49", null ],
    [ "next", "variables_8h.html#a0703dc88719f4ae8cfa29d85f0bc638d", null ],
    [ "prev", "variables_8h.html#a210d994c23c0a4f644d9c02b9e72c799", null ],
    [ "text", "variables_8h.html#a226444bf45071830bb8785537762a3cb", null ]
];