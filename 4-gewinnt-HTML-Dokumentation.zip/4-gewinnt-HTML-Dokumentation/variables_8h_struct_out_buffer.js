var variables_8h_struct_out_buffer =
[
    [ "first", "variables_8h.html#a87ad277d7219959ab239794feaf422d7", null ],
    [ "hAlign", "variables_8h.html#a57f4522e11f4815aef01edfee3de8693", null ],
    [ "last", "variables_8h.html#a92a74ebc38d9b7724473549854cf1dc0", null ],
    [ "lineCount", "variables_8h.html#aae000e2b702d7d3897bbfef5adb11c29", null ],
    [ "maxTextLength", "variables_8h.html#af43d5a922da18db29dc86b5a38543357", null ],
    [ "vAlign", "variables_8h.html#a9bf861ad5c68cbe7798302a20b5ac463", null ]
];