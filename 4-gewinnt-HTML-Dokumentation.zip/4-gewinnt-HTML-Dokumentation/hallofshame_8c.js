var hallofshame_8c =
[
    [ "extractMoves", "hallofshame_8c.html#a4b0e4e7abd07e8aa82d0edcefb415142", null ],
    [ "getOldFileLength", "hallofshame_8c.html#a93a8975b6852b8b59d8f8667f36ecba0", null ],
    [ "showHallOfShame", "hallofshame_8c.html#aa00533bd55f5e103786e415b2427bb56", null ],
    [ "updateSaveHoS", "hallofshame_8c.html#aed3a48687a8f8f59fc007b0e40db1ab3", null ]
];