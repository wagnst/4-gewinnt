var annotated =
[
    [ "board", "variables_8h.html#structboard", "variables_8h_structboard" ],
    [ "LineItem", "variables_8h.html#struct_line_item", "variables_8h_struct_line_item" ],
    [ "OutBuffer", "variables_8h.html#struct_out_buffer", "variables_8h_struct_out_buffer" ]
];