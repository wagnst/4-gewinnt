var searchData=
[
  ['userinput',['userInput',['../variables_8h.html#a08fe5b81aa0319d6710ea7c7b085509a',1,'variables.h']]],
  ['utf_5fmultiplier',['UTF_MULTIPLIER',['../variables_8h.html#a9c7390483d364a0236a6e7d6efc04ad9',1,'variables.h']]]
];
