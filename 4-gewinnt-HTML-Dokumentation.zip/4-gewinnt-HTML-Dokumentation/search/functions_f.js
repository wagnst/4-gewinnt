var searchData=
[
  ['updatesavehos',['updateSaveHoS',['../hallofshame_8c.html#aed3a48687a8f8f59fc007b0e40db1ab3',1,'updateSaveHoS(char *victor, char *victim, int moves):&#160;hallofshame.c'],['../signatures_8h.html#aed3a48687a8f8f59fc007b0e40db1ab3',1,'updateSaveHoS(char *victor, char *victim, int moves):&#160;hallofshame.c']]]
];
