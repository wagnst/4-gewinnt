var searchData=
[
  ['addframe',['addFrame',['../rules_8c.html#ab6ca730042cb162571cb403dfaa5a4e8',1,'rules.c']]],
  ['animatebanner',['animateBanner',['../signatures_8h.html#ac262850c1cbfc0e20ab1cb807aee901a',1,'animateBanner(int slideIn):&#160;system.c'],['../system_8c.html#ac262850c1cbfc0e20ab1cb807aee901a',1,'animateBanner(int slideIn):&#160;system.c']]],
  ['animatebox',['animateBox',['../signatures_8h.html#af937aa3025f34bbfad7976c0ceb5b6b6',1,'animateBox(int wFrom, int hFrom, int wTo, int hTo):&#160;system.c'],['../system_8c.html#af937aa3025f34bbfad7976c0ceb5b6b6',1,'animateBox(int wFrom, int hFrom, int wTo, int hTo):&#160;system.c']]],
  ['animatefalling',['animateFalling',['../gamefunction_8c.html#aedf01a36f81b28e539c99f53543efbbd',1,'animateFalling(struct board *currBoard, unsigned int xPos, char CoinType):&#160;gamefunction.c'],['../signatures_8h.html#aa4fc6e6e661f7a4dba70ac76f76ebb7e',1,'animateFalling(struct board *currBoard, unsigned int yPos, char CoinType):&#160;gamefunction.c']]]
];
