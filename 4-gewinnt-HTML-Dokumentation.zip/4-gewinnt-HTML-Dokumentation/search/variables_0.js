var searchData=
[
  ['align',['align',['../variables_8h.html#a1a9adf6b9d56e489b08ae59280037ecf',1,'LineItem']]]
];
