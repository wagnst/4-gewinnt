var searchData=
[
  ['setfancy',['setFancy',['../fancyfont_8c.html#a62485c012c2a1c3528e5df19a69cdc9b',1,'setFancy(int fancyActivated):&#160;fancyfont.c'],['../signatures_8h.html#ac9dd597e531f0b33a8b4abee4b169aaf',1,'setFancy():&#160;signatures.h']]],
  ['setfield',['setField',['../board_8c.html#ab0314fc030a3d0d9a0e2a5d4fad73bd0',1,'setField(struct board *target, int x, int y, char value):&#160;board.c'],['../signatures_8h.html#ab0314fc030a3d0d9a0e2a5d4fad73bd0',1,'setField(struct board *target, int x, int y, char value):&#160;board.c']]],
  ['setlinealign',['setLineAlign',['../signatures_8h.html#a09ed5dcaae860a161fb8b760e6fd59f7',1,'setLineAlign(int align):&#160;system.c'],['../system_8c.html#a09ed5dcaae860a161fb8b760e6fd59f7',1,'setLineAlign(int align):&#160;system.c']]],
  ['showcredits',['showCredits',['../credits_8c.html#ac0a40af75d169dc19259d9c8426dbecd',1,'showCredits():&#160;credits.c'],['../signatures_8h.html#ac0a40af75d169dc19259d9c8426dbecd',1,'showCredits():&#160;credits.c']]],
  ['showhallofshame',['showHallOfShame',['../hallofshame_8c.html#aa00533bd55f5e103786e415b2427bb56',1,'showHallOfShame(int highlight, int startFrom):&#160;hallofshame.c'],['../signatures_8h.html#aa00533bd55f5e103786e415b2427bb56',1,'showHallOfShame(int highlight, int startFrom):&#160;hallofshame.c']]],
  ['showrules',['showRules',['../rules_8c.html#a3fc16568c796078d9294f977d0d33a83',1,'showRules():&#160;rules.c'],['../signatures_8h.html#a3fc16568c796078d9294f977d0d33a83',1,'showRules():&#160;rules.c']]],
  ['startbuffer',['startBuffer',['../signatures_8h.html#a7025362e49b3e0b8417d036ae412f1fa',1,'startBuffer(int maxTextLength):&#160;system.c'],['../system_8c.html#a7025362e49b3e0b8417d036ae412f1fa',1,'startBuffer(int maxTextLength):&#160;system.c']]],
  ['startgame',['startGame',['../gamefunction_8c.html#ab1f321a2f17fa8ba0f5ab4e2621fd6d6',1,'startGame():&#160;gamefunction.c'],['../signatures_8h.html#ab1f321a2f17fa8ba0f5ab4e2621fd6d6',1,'startGame():&#160;gamefunction.c']]],
  ['strcatrepeat',['strcatRepeat',['../signatures_8h.html#a3c9d83905eaf8cbe0888ad9e2f419833',1,'strcatRepeat(char *target, const char *source, unsigned int howOften):&#160;system.c'],['../system_8c.html#a3c9d83905eaf8cbe0888ad9e2f419833',1,'strcatRepeat(char *target, const char *source, unsigned int howOften):&#160;system.c']]]
];
