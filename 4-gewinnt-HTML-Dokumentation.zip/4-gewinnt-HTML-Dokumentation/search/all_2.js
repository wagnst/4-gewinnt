var searchData=
[
  ['calcfieldaddress',['calcFieldAddress',['../board_8c.html#a46db977f6db0fd0825f5ef5108c30e9e',1,'calcFieldAddress(struct board *target, int x, int y):&#160;board.c'],['../signatures_8h.html#a46db977f6db0fd0825f5ef5108c30e9e',1,'calcFieldAddress(struct board *target, int x, int y):&#160;board.c']]],
  ['checkdraw',['checkDraw',['../gamefunction_8c.html#af50ec8f99b4ba00b14bf5cb7c7ee9f9d',1,'checkDraw():&#160;gamefunction.c'],['../signatures_8h.html#af50ec8f99b4ba00b14bf5cb7c7ee9f9d',1,'checkDraw():&#160;gamefunction.c']]],
  ['checkforwinner',['checkForWinner',['../gamefunction_8c.html#a42025a8656aaf0a1e18e7597ce1ea21c',1,'checkForWinner(int x, int y, char player):&#160;gamefunction.c'],['../signatures_8h.html#a42025a8656aaf0a1e18e7597ce1ea21c',1,'checkForWinner(int x, int y, char player):&#160;gamefunction.c']]],
  ['clearall',['clearAll',['../gamefunction_8c.html#a798729dca95209ecdc609807a653a2bf',1,'clearAll():&#160;gamefunction.c'],['../signatures_8h.html#a798729dca95209ecdc609807a653a2bf',1,'clearAll():&#160;gamefunction.c']]],
  ['clearboard',['clearBoard',['../board_8c.html#aaf722a3aee3bf1d85e57eef1a4c4f02a',1,'clearBoard(struct board *target):&#160;board.c'],['../signatures_8h.html#aaf722a3aee3bf1d85e57eef1a4c4f02a',1,'clearBoard(struct board *target):&#160;board.c']]],
  ['coinposition',['coinPosition',['../gamefunction_8c.html#a1ea724989282f1233e7354b2e74b914d',1,'coinPosition():&#160;gamefunction.c'],['../variables_8h.html#a1ea724989282f1233e7354b2e74b914d',1,'coinPosition():&#160;gamefunction.c']]],
  ['con',['con',['../variables_8h.html#a8db35bac6311b6ba0e49b67bad57ddae',1,'variables.h']]],
  ['consolebufferheight',['consoleBufferHeight',['../system_8c.html#a2673793ae3c1dd1d549abfaaa2aea1cf',1,'consoleBufferHeight():&#160;system.c'],['../variables_8h.html#a2673793ae3c1dd1d549abfaaa2aea1cf',1,'consoleBufferHeight():&#160;system.c']]],
  ['consolebufferwidth',['consoleBufferWidth',['../system_8c.html#aa4883d896880fcc572cd390c091bb2ef',1,'consoleBufferWidth():&#160;system.c'],['../variables_8h.html#aa4883d896880fcc572cd390c091bb2ef',1,'consoleBufferWidth():&#160;system.c']]],
  ['consoleclear',['consoleClear',['../signatures_8h.html#ae313c1a63d6f75165c186e23ede3f886',1,'consoleClear():&#160;system.c'],['../system_8c.html#ae313c1a63d6f75165c186e23ede3f886',1,'consoleClear():&#160;system.c']]],
  ['content',['content',['../variables_8h.html#a832d2b06af80b3937fb5b9bbd451a089',1,'board']]],
  ['copychar',['copyChar',['../signatures_8h.html#acca9c7a0097972b4bcb8afb753ad34c2',1,'copyChar(char *src, char *dst):&#160;system.c'],['../system_8c.html#acca9c7a0097972b4bcb8afb753ad34c2',1,'copyChar(char *src, char *dst):&#160;system.c']]],
  ['credits_2ec',['credits.c',['../credits_8c.html',1,'']]],
  ['csbi',['csbi',['../system_8c.html#a36d01b46e02a7644af5a0a9d2ff2c83a',1,'csbi():&#160;system.c'],['../variables_8h.html#a36d01b46e02a7644af5a0a9d2ff2c83a',1,'csbi():&#160;system.c']]]
];
