var searchData=
[
  ['throwcoin',['throwCoin',['../gamefunction_8c.html#ad1f279dc9f093c9a39000f5a6a077216',1,'throwCoin(int pos, char player):&#160;gamefunction.c'],['../signatures_8h.html#ad1f279dc9f093c9a39000f5a6a077216',1,'throwCoin(int pos, char player):&#160;gamefunction.c']]]
];
