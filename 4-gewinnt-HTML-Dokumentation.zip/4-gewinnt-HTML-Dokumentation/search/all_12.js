var searchData=
[
  ['valign',['vAlign',['../variables_8h.html#a9bf861ad5c68cbe7798302a20b5ac463',1,'OutBuffer']]],
  ['variables_2eh',['variables.h',['../variables_8h.html',1,'']]],
  ['victor',['victor',['../gamefunction_8c.html#accb7cc35835fb3e126f4e4cb5f9d0450',1,'victor():&#160;gamefunction.c'],['../variables_8h.html#accb7cc35835fb3e126f4e4cb5f9d0450',1,'victor():&#160;gamefunction.c']]]
];
