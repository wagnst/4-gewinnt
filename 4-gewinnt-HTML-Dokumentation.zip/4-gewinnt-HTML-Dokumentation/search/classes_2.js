var searchData=
[
  ['outbuffer',['OutBuffer',['../variables_8h.html#struct_out_buffer',1,'']]]
];
