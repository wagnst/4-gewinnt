var searchData=
[
  ['output_5fmaxbuffer',['OUTPUT_MAXBUFFER',['../variables_8h.html#a3958bd84b7abe55d3e0ccb9fe87985a1',1,'variables.h']]]
];
