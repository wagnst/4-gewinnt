var searchData=
[
  ['name1',['name1',['../variables_8h.html#a7e659e3575ffe840707a069b0cd092a9',1,'variables.h']]],
  ['name2',['name2',['../variables_8h.html#a3834540f96ed439a0e2737f7f1e4889f',1,'variables.h']]],
  ['neighbourrow',['neighbourRow',['../gamefunction_8c.html#ab00ce6c274e49e96ee206427e2095d5d',1,'neighbourRow(int x, int y, int xMovement, int yMovement, char player):&#160;gamefunction.c'],['../signatures_8h.html#ab00ce6c274e49e96ee206427e2095d5d',1,'neighbourRow(int x, int y, int xMovement, int yMovement, char player):&#160;gamefunction.c']]],
  ['newboard',['newBoard',['../board_8c.html#aa832cfb270f47cdcb3afca65656dd964',1,'newBoard(struct board *target, unsigned int width, unsigned int height):&#160;board.c'],['../signatures_8h.html#aa832cfb270f47cdcb3afca65656dd964',1,'newBoard(struct board *target, unsigned int width, unsigned int height):&#160;board.c']]],
  ['next',['next',['../variables_8h.html#a0703dc88719f4ae8cfa29d85f0bc638d',1,'LineItem']]],
  ['no_5fhighlight',['NO_HIGHLIGHT',['../variables_8h.html#aefd07acc2f74bd35c37a9479c7dd515b',1,'variables.h']]],
  ['numberoffields',['numberOfFields',['../variables_8h.html#acbd532e74dde0e17908138cf3abe7ae9',1,'board']]]
];
