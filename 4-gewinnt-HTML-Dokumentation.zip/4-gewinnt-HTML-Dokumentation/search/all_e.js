var searchData=
[
  ['readme',['README',['../md__n_1__niko__coding__c_09_09_4-gewinnt__r_e_a_d_m_e.html',1,'']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['resource_2eh',['resource.h',['../resource_8h.html',1,'']]],
  ['rules_2ec',['rules.c',['../rules_8c.html',1,'']]]
];
