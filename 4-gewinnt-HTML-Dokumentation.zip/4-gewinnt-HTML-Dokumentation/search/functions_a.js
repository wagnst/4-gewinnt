var searchData=
[
  ['neighbourrow',['neighbourRow',['../gamefunction_8c.html#ab00ce6c274e49e96ee206427e2095d5d',1,'neighbourRow(int x, int y, int xMovement, int yMovement, char player):&#160;gamefunction.c'],['../signatures_8h.html#ab00ce6c274e49e96ee206427e2095d5d',1,'neighbourRow(int x, int y, int xMovement, int yMovement, char player):&#160;gamefunction.c']]],
  ['newboard',['newBoard',['../board_8c.html#aa832cfb270f47cdcb3afca65656dd964',1,'newBoard(struct board *target, unsigned int width, unsigned int height):&#160;board.c'],['../signatures_8h.html#aa832cfb270f47cdcb3afca65656dd964',1,'newBoard(struct board *target, unsigned int width, unsigned int height):&#160;board.c']]]
];
