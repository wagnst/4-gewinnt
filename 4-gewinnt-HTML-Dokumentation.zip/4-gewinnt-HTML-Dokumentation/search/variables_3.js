var searchData=
[
  ['display',['display',['../system_8c.html#a720bc75a20372a363078f6d1b1d681e7',1,'display():&#160;system.c'],['../variables_8h.html#a720bc75a20372a363078f6d1b1d681e7',1,'display():&#160;system.c']]]
];
