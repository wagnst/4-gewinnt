var searchData=
[
  ['testervariable',['testerVariable',['../dummy_8c.html#a892062288f78601a35f1657d7434a269',1,'testerVariable():&#160;dummy.c'],['../variables_8h.html#a892062288f78601a35f1657d7434a269',1,'testerVariable():&#160;dummy.c']]],
  ['text',['text',['../variables_8h.html#a226444bf45071830bb8785537762a3cb',1,'LineItem']]]
];
