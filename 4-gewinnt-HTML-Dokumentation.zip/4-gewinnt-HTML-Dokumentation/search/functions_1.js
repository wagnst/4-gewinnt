var searchData=
[
  ['calcfieldaddress',['calcFieldAddress',['../board_8c.html#a46db977f6db0fd0825f5ef5108c30e9e',1,'calcFieldAddress(struct board *target, int x, int y):&#160;board.c'],['../signatures_8h.html#a46db977f6db0fd0825f5ef5108c30e9e',1,'calcFieldAddress(struct board *target, int x, int y):&#160;board.c']]],
  ['checkdraw',['checkDraw',['../gamefunction_8c.html#af50ec8f99b4ba00b14bf5cb7c7ee9f9d',1,'checkDraw():&#160;gamefunction.c'],['../signatures_8h.html#af50ec8f99b4ba00b14bf5cb7c7ee9f9d',1,'checkDraw():&#160;gamefunction.c']]],
  ['checkforwinner',['checkForWinner',['../gamefunction_8c.html#a42025a8656aaf0a1e18e7597ce1ea21c',1,'checkForWinner(int x, int y, char player):&#160;gamefunction.c'],['../signatures_8h.html#a42025a8656aaf0a1e18e7597ce1ea21c',1,'checkForWinner(int x, int y, char player):&#160;gamefunction.c']]],
  ['clearall',['clearAll',['../gamefunction_8c.html#a798729dca95209ecdc609807a653a2bf',1,'clearAll():&#160;gamefunction.c'],['../signatures_8h.html#a798729dca95209ecdc609807a653a2bf',1,'clearAll():&#160;gamefunction.c']]],
  ['clearboard',['clearBoard',['../board_8c.html#aaf722a3aee3bf1d85e57eef1a4c4f02a',1,'clearBoard(struct board *target):&#160;board.c'],['../signatures_8h.html#aaf722a3aee3bf1d85e57eef1a4c4f02a',1,'clearBoard(struct board *target):&#160;board.c']]],
  ['consoleclear',['consoleClear',['../signatures_8h.html#ae313c1a63d6f75165c186e23ede3f886',1,'consoleClear():&#160;system.c'],['../system_8c.html#ae313c1a63d6f75165c186e23ede3f886',1,'consoleClear():&#160;system.c']]],
  ['copychar',['copyChar',['../signatures_8h.html#acca9c7a0097972b4bcb8afb753ad34c2',1,'copyChar(char *src, char *dst):&#160;system.c'],['../system_8c.html#acca9c7a0097972b4bcb8afb753ad34c2',1,'copyChar(char *src, char *dst):&#160;system.c']]]
];
