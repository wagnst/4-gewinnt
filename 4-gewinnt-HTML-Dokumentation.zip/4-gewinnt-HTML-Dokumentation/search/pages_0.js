var searchData=
[
  ['readme',['README',['../md__n_1__niko__coding__c_09_09_4-gewinnt__r_e_a_d_m_e.html',1,'']]]
];
