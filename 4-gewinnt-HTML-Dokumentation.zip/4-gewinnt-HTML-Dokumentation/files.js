var files =
[
    [ "board.c", "board_8c.html", "board_8c" ],
    [ "credits.c", "credits_8c.html", "credits_8c" ],
    [ "dummy.c", "dummy_8c.html", "dummy_8c" ],
    [ "fancyfont.c", "fancyfont_8c.html", "fancyfont_8c" ],
    [ "gamefunction.c", "gamefunction_8c.html", "gamefunction_8c" ],
    [ "hallofshame.c", "hallofshame_8c.html", "hallofshame_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "mainMenu.c", "main_menu_8c.html", "main_menu_8c" ],
    [ "resource.h", "resource_8h.html", "resource_8h" ],
    [ "rules.c", "rules_8c.html", "rules_8c" ],
    [ "signatures.h", "signatures_8h.html", "signatures_8h" ],
    [ "system.c", "system_8c.html", "system_8c" ],
    [ "variables.h", "variables_8h.html", "variables_8h" ],
    [ "winlauncher.c", "winlauncher_8c.html", "winlauncher_8c" ]
];