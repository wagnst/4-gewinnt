var variables_8h_structboard =
[
    [ "content", "variables_8h.html#a832d2b06af80b3937fb5b9bbd451a089", null ],
    [ "height", "variables_8h.html#adc7cd5d0cf80217e1af088aeae171ac1", null ],
    [ "numberOfFields", "variables_8h.html#acbd532e74dde0e17908138cf3abe7ae9", null ],
    [ "width", "variables_8h.html#aec09ce7d9b2ef743e51ace3e41148eff", null ]
];