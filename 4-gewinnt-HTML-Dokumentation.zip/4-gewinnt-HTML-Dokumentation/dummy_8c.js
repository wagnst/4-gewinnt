var dummy_8c =
[
    [ "HelloWorld", "dummy_8c.html#ae16d29305d03dd6abced14ecd0293bd8", null ],
    [ "testerVariable", "dummy_8c.html#a892062288f78601a35f1657d7434a269", null ]
];